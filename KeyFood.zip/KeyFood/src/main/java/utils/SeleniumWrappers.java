package utils;


import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.TestException;
import tests.BaseTest;

public class SeleniumWrappers extends BaseTest {

    public void hoverElement(WebElement element){
        try{
            waitForElementToBeDisplayed(element);
            Actions actions = new Actions(driver);
            actions.moveToElement(element).perform();
        }
        catch (Exception e){
            throw  new TestException("Element is not displayed");
        }
    }

    public void dragAndDropSlider(WebElement element,int xOffset,int yOffset){
        try{
            waitForElementToBeDisplayed(element);
            Actions actions = new Actions(driver);
            actions.dragAndDropBy(element,xOffset,yOffset).perform();
        }catch (Exception e){
            throw new TestException("Element is not displayed");
        }
    }

    public void doubleClick(WebElement element){
        try{
            waitForElementToBeDisplayed(element);
            Actions actions = new Actions(driver);
            actions.doubleClick(element).perform();
        }catch (Exception e){
            throw  new TestException("Element is not displayed" );}
    }

    public void waitForElementToBeDisplayed(WebElement element){
        try {
            Log.info("Called the <waitForElementToBeDisplayed> on element" + element);
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.visibilityOf(element));
        }catch (Exception e){
            Log.error(e.getStackTrace().toString());
            throw new TestException("The element was not present");
        }
    }

    public void waitForElementToBeClickable(WebElement element){
        try{
            Log.info("Called the <waitForElementToBeClickable> on element" + element);
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.elementToBeClickable(element));
        }catch (Exception e){
            Log.error(e.getStackTrace().toString());
            throw new TestException("The element is not clickable");
        }
    }

    public void waitForElementToHaveValue(WebElement element,String string){
        try{
            Log.info("Called the <waitForElementToHaveValue> on element" + element);
            WebDriverWait wait = new WebDriverWait(driver,10);
            wait.until(ExpectedConditions.textToBePresentInElement(element,string));
        }catch (Exception e){
            Log.error(e.getStackTrace().toString());
            throw new TestException("The element is not clickable");
        }
    }


    /**
     * Method used to select from dropdown
     * @param element WebElement to be selected
     * @param selectByValue Desired value from list to be set
     */
    public void selectFromDropdown(WebElement element,String selectByValue){
        Log.info("Called the <select> on element" + element);
        waitForElementToBeDisplayed(element);
        try{
        Select select = new Select(element);
        select.selectByValue(selectByValue);}
        catch (Exception e){
            Log.error(e.getStackTrace().toString());
            throw new TestException("The element is not present");
        }
    }


    /**
     * Method used to select from dropdown
     * @param element WebElement to be selected
     * @param selectByIndex Desired index from list to be set
     */
    public void selectFromDropdown(WebElement element,int selectByIndex){
        Log.info("Called the <select> on element" + element);
        waitForElementToBeDisplayed(element);
        try{
            Select select = new Select(element);
            select.selectByIndex(selectByIndex);}
        catch (Exception e){
            Log.error(e.getStackTrace().toString());
            throw new TestException("The element is not present");
        }
    }

    /**
     * Method used to send key values (String) to an input textarea field
     * @param element : WebElement that receives the text input
     * @param value : The string value to be sent
     */

    public void sendKeys(WebElement element,String value){
        try{element.clear();
            element.sendKeys(value);
        }catch (Exception e){
            throw new TestException("The element is not present");
        }

    }

    /**
     * Method used to click on elements. Makes use of waitForElement to be clickable (element)
     * @param element : element to be click on (type WebElement)
     */

    public void click(WebElement element){
        Log.info("Called the <click> on element" + element);
        waitForElementToBeClickable(element);
        try {
            element.click();
        }catch (StaleElementReferenceException e){
            Log.error("error catched StaleElementReferenceException");
            element.click();
        }catch (Exception e){
            throw new TestException("Element is not clickable");
        }
    }

    /**
     * This is a method which returns an integer value from 100 (inclusive) to 10000 (exclusive)
     * @return an integer random number
     */
    public int intRandomNumber(){
        int randomNumber = (int)(Math.random()*(10000-100+1)+100);
            return randomNumber;
    }

}
