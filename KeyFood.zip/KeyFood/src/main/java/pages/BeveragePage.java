package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

public class BeveragePage extends SeleniumWrappers {
    WebDriver driver;

    public BeveragePage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(linkText = "Coca-Cola – 2 L Bottle") public WebElement cocaCola2L;
    @FindBy(partialLinkText = "Add to cart") public WebElement addToCartBtn;
}
