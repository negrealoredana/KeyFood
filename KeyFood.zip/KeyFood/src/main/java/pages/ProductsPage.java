package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

public class ProductsPage extends SeleniumWrappers {
    WebDriver driver;

    public ProductsPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(name = "add-to-cart") public WebElement addToCartBtn;
    @FindBy(className = "woocommerce-message") public WebElement addToCartMsg;
    @FindBy(linkText = "View cart") public WebElement viewCart;


}
