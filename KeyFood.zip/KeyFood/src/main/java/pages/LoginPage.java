package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.ReadProperties;
import utils.SeleniumWrappers;

public class LoginPage extends SeleniumWrappers {
    WebDriver driver;
    public String username = ReadProperties.config.getProperty("username");
    public String password = ReadProperties.config.getProperty("password");

    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(id="username") public WebElement usernameField;
    @FindBy(id="password") public WebElement passwordField;
    @FindBy(name = "login") public WebElement loginBtn;
    @FindBy(linkText ="Log out") public WebElement logoutBtn;

    public void loginInApp(){
        sendKeys(usernameField,username);
        sendKeys(passwordField,password);
        click(loginBtn);
    }

}
