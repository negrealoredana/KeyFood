package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

public class CheckOutPage extends SeleniumWrappers {
    WebDriver driver;

    public CheckOutPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(className = "woocommerce-terms-and-conditions-checkbox-text") public WebElement agreeConditions;
    @FindBy(id="place_order") public WebElement placeOrderBtn;
    @FindBy(css = "p[class*='woocommerce-thankyou-order-received']") public WebElement confirmationText;
    @FindBy(xpath = "//li[@class='woocommerce-order-overview__order order']/strong") public WebElement orderId;
    @FindBy(id="billing_first_name") public WebElement firstNameField;
    @FindBy(id="billing_last_name") public WebElement lastNameField;
    @FindBy(id="billing_company") public WebElement companyField;
    @FindBy(id ="billing_country") public WebElement countryDrillDown;
    @FindBy(id ="billing_address_1") public WebElement addressStreetNoField;
    @FindBy(id="billing_address_2") public WebElement addressOtherField;
    @FindBy(id="billing_city") public WebElement cityField;
    @FindBy(id = "billing_state") public WebElement countyDrillDown;
    @FindBy(id="billing_postcode") public WebElement postCodeField;
    @FindBy(id="billing_phone") public WebElement phoneField;
    @FindBy(id="billing_email") public WebElement emailField;
    @FindBy(id="order_comments") public WebElement commentsField;




}
