package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

import java.util.List;

public class CartPage extends SeleniumWrappers {
    WebDriver driver;

    public CartPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(className = "klbth-icon-plus") public WebElement increseQtyBtn;
    @FindBy(tagName = "bdi") public List<WebElement> price;
    @FindBy(linkText = "Proceed to checkout") public WebElement proceedToCheckOutBtn;
    @FindBy(id="coupon_code") public WebElement couponCode;
    @FindBy(name = "apply_coupon") public  WebElement applyCouponBtn;
    @FindBy(linkText = "[Remove]") public WebElement removeCoupon;


}
