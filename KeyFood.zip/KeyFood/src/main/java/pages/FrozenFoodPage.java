package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;


public class FrozenFoodPage extends SeleniumWrappers {
    WebDriver driver;

    public FrozenFoodPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(linkText = "Haagen-Dazs Caramel Cone Ice Cream") public WebElement iceCreamHaagenCaramel;
    @FindBy(linkText = "Organic Frozen Triple Berry Blend") public WebElement frozenBeryFruits;
    @FindBy(partialLinkText = "Add to cart") public WebElement addToCartBtn;




}
