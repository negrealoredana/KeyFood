package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

public class BlogPage extends SeleniumWrappers {

    WebDriver driver;

    public BlogPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(partialLinkText = "this mistaken idea") public WebElement blogPostWater;
    @FindBy(partialLinkText = "Typefaces on the Web") public WebElement blogPostChoco;
    @FindBy(partialLinkText = "Donut Desserts") public WebElement blogPostIceCream;
    @FindBy(partialLinkText = "denounce with righteous") public WebElement blogPostNutella;



}
