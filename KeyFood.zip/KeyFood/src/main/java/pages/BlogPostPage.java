package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

import java.util.List;

public class BlogPostPage extends SeleniumWrappers {
    WebDriver driver;

    public BlogPostPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }

    @FindBy(id="comment") public WebElement commentField;
    @FindBy(id="author") public WebElement nameField;
    @FindBy(id="email") public WebElement emailField;
    @FindBy(id="url") public WebElement websiteField;
    @FindBy(id = "wp-comment-cookies-consent") public WebElement saveUserCkbox;
    @FindBy(id ="submit") public WebElement submitBtn;
    @FindBy(css = "a[class='url']" ) public List<WebElement> nameComments;
    @FindBy(xpath = "//div[@class='klb-post']/p") public List<WebElement> msgComments;
    @FindBy(xpath = "//div[@class='klb-post']/em") public WebElement awaitingComments;

    @FindBy(linkText = "« Back") public WebElement backOnPostingTooFast;

    /**
     * Method to overcome warning appeared when posting comments to fast
     * @param tabName: Name of the tab when error is shown. In case error is no longer present script will exit while loop
     * @param elementBack: Name of the WebElement on which script will click to return on comments page and try submission again
     * @param elementTryAgain: Name of WebElement on which script will click in order to resubmit comment
     */
    public void overcomeCommentFailure(String tabName,WebElement elementBack,WebElement elementTryAgain){
        while(driver.getTitle().equals(tabName)){
            click(elementBack);
            click(elementTryAgain);}
    }

}
