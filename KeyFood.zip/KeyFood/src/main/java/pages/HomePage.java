package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.SeleniumWrappers;

public class HomePage extends SeleniumWrappers {
    WebDriver driver;

    public HomePage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);   }

    @FindBy(linkText = "My account") public WebElement myAccount;
    @FindBy(id="dgwt-wcas-search-input-1") public WebElement searchBar;
    @FindBy(className = "cart-count-icon") public WebElement noOfItemsInCart;
    @FindBy(xpath = "//a[@data-target='#all-categories']") public WebElement allCategoryMenu;
    @FindBy(linkText = "Frozen Foods") public WebElement frozenFoodCategory;
    @FindBy(linkText = "Beverages") public WebElement beveragesCategory;
    @FindBy(linkText = "BLOG") public WebElement blogPage;


}
