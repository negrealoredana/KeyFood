package tests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.*;
import utils.TestNgListener;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

@Listeners(TestNgListener.class)
public class E2ETest2 extends BaseTest {
    HomePage homePage;
    FrozenFoodPage frozenFoodPage;
    BeveragePage beveragePage;
    CartPage cartPage;
    CheckOutPage checkOutPage;

    @Test
    public void checkOrderPlacementNewClient() {
        homePage = new HomePage(driver);
        homePage.click(homePage.frozenFoodCategory);
        frozenFoodPage = new FrozenFoodPage(driver);
        frozenFoodPage.hoverElement(frozenFoodPage.iceCreamHaagenCaramel);
        frozenFoodPage.click(frozenFoodPage.addToCartBtn);
        frozenFoodPage.hoverElement(frozenFoodPage.frozenBeryFruits);
        frozenFoodPage.click(frozenFoodPage.addToCartBtn);
        homePage.click(homePage.allCategoryMenu);
        homePage.click(homePage.beveragesCategory);
        beveragePage = new BeveragePage(driver);
        beveragePage.hoverElement(beveragePage.cocaCola2L);
        beveragePage.click(beveragePage.addToCartBtn);
        homePage.click(homePage.noOfItemsInCart);
        cartPage = new CartPage(driver);
        assertEquals(cartPage.price.get(12).getText(),"$23.12");
        cartPage.sendKeys(cartPage.couponCode, "keyfood31122021");
        cartPage.click(cartPage.applyCouponBtn);
        homePage.waitForElementToBeDisplayed(cartPage.removeCoupon);
        assertEquals(cartPage.price.get(12).getText(),"$11.56");
        cartPage.click(cartPage.proceedToCheckOutBtn);
        checkOutPage = new CheckOutPage(driver);
        checkOutPage.sendKeys(checkOutPage.firstNameField,"Loredana");
        checkOutPage.sendKeys(checkOutPage.lastNameField,"Negrea");
        checkOutPage.sendKeys(checkOutPage.companyField,"My Company SRL");
        checkOutPage.selectFromDropdown(checkOutPage.countryDrillDown,"RO");
        checkOutPage.sendKeys(checkOutPage.addressStreetNoField,"This is my address no 123");
        checkOutPage.sendKeys(checkOutPage.addressOtherField,"bl 123 sc 123 et 123 ap 123");
        checkOutPage.sendKeys(checkOutPage.cityField,"Bucuresti");
        checkOutPage.selectFromDropdown(checkOutPage.countyDrillDown,"B");
        checkOutPage.sendKeys(checkOutPage.postCodeField,"123456");
        checkOutPage.sendKeys(checkOutPage.phoneField,"0123456789");
        checkOutPage.sendKeys(checkOutPage.emailField,"myemail@myemail.ro");
        checkOutPage.sendKeys(checkOutPage.commentsField,"Please deliver Mo - Fri from 9am to 5pm");
        checkOutPage.click(checkOutPage.agreeConditions);
        checkOutPage.click(checkOutPage.placeOrderBtn);
        assertEquals(checkOutPage.confirmationText.getText(),"Thank you. Your order has been received.");
        assertNotNull(checkOutPage.orderId);
    }


}
