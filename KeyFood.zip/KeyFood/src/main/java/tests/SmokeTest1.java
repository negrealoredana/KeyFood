package tests;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.BlogPage;
import pages.BlogPostPage;
import pages.HomePage;
import utils.TestNgListener;

import static org.testng.Assert.*;

@Listeners(TestNgListener.class)
public class SmokeTest1 extends BaseTest{
    HomePage homePage;
    BlogPage blogPage;
    BlogPostPage blogPostPage;

    @Test
    public void checkFirstBlogPostAndComments(){
        homePage = new HomePage(driver);
        homePage.click(homePage.blogPage);
        blogPage = new BlogPage(driver);
        assertTrue(blogPage.blogPostWater.isDisplayed());
        assertTrue(blogPage.blogPostChoco.isDisplayed());
        assertTrue(blogPage.blogPostIceCream.isDisplayed());
        assertTrue(blogPage.blogPostNutella.isDisplayed());
        blogPage.click(blogPage.blogPostWater);
        blogPostPage = new BlogPostPage(driver);
        blogPostPage.sendKeys(blogPostPage.commentField, "Nice reading.");
        blogPostPage.sendKeys(blogPostPage.nameField, "My Name");
        blogPostPage.sendKeys(blogPostPage.emailField, "mymail_"+ blogPostPage.intRandomNumber()+"@mymail.com");
        blogPostPage.sendKeys(blogPostPage.websiteField, "www.blablasite.com");
        blogPostPage.click(blogPostPage.saveUserCkbox);
        blogPostPage.click(blogPostPage.submitBtn);
        assertEquals(blogPostPage.nameComments.get(blogPostPage.nameComments.size() - 1).getText(), "My Name");
        assertEquals(blogPostPage.msgComments.get(blogPostPage.msgComments.size() - 1).getText(), "Nice reading.");
        assertEquals(blogPostPage.awaitingComments.getText(), "Your comment is awaiting moderation.");
        homePage.click(homePage.blogPage);
        blogPage.click(blogPage.blogPostChoco);
        blogPostPage = new BlogPostPage(driver);
        blogPostPage.sendKeys(blogPostPage.commentField, "This is a great article.");
        blogPostPage.sendKeys(blogPostPage.nameField, "BoHoHo");
        blogPostPage.sendKeys(blogPostPage.emailField, "bohoho_"+blogPostPage.intRandomNumber()+"@bohoho.com");
        blogPostPage.websiteField.clear();
        blogPostPage.click(blogPostPage.saveUserCkbox);
        blogPostPage.click(blogPostPage.submitBtn);
        blogPostPage.overcomeCommentFailure("Comment Submission Failure", blogPostPage.backOnPostingTooFast, blogPostPage.submitBtn);
        assertEquals(blogPostPage.nameComments.get(blogPostPage.nameComments.size()-1).getText(),"BoHoHo");
        assertEquals(blogPostPage.msgComments.get(blogPostPage.msgComments.size()-1).getText(),"This is a great article.");
        assertEquals(blogPostPage.awaitingComments.getText(),"Your comment is awaiting moderation.");
        homePage.click(homePage.blogPage);
        blogPage.click(blogPage.blogPostIceCream);
        blogPostPage = new BlogPostPage(driver);
        blogPostPage.sendKeys(blogPostPage.commentField, "Bla bla article.");
        blogPostPage.sendKeys(blogPostPage.nameField, "Merry Christmas");
        blogPostPage.sendKeys(blogPostPage.emailField, "santa_"+blogPostPage.intRandomNumber()+"@santa.com");
        assertTrue(blogPostPage.websiteField.isDisplayed());
        assertTrue(blogPostPage.saveUserCkbox.isDisplayed());
        blogPostPage.click(blogPostPage.submitBtn);
        blogPostPage.overcomeCommentFailure("Comment Submission Failure", blogPostPage.backOnPostingTooFast, blogPostPage.submitBtn);
        assertEquals(blogPostPage.nameComments.get(blogPostPage.nameComments.size()-1).getText(),"Merry Christmas");
        assertEquals(blogPostPage.msgComments.get(blogPostPage.msgComments.size()-1).getText(),"Bla bla article.");
        assertEquals(blogPostPage.awaitingComments.getText(),"Your comment is awaiting moderation.");
        homePage.click(homePage.blogPage);
        blogPage.click(blogPage.blogPostNutella);
        blogPostPage = new BlogPostPage(driver);
        blogPostPage.sendKeys(blogPostPage.commentField, "A moment on your lips forever on your hips.");
        blogPostPage.sendKeys(blogPostPage.nameField, "Joey Is Here");
        blogPostPage.sendKeys(blogPostPage.emailField, "Jemappele_"+blogPostPage.intRandomNumber()+"@claude.com");
        assertTrue(blogPostPage.websiteField.isDisplayed());
        assertTrue(blogPostPage.saveUserCkbox.isDisplayed());
        blogPostPage.click(blogPostPage.submitBtn);
        blogPostPage.overcomeCommentFailure("Comment Submission Failure", blogPostPage.backOnPostingTooFast, blogPostPage.submitBtn);
        assertEquals(blogPostPage.nameComments.get(blogPostPage.nameComments.size()-1).getText(),"Joey Is Here");
        assertEquals(blogPostPage.msgComments.get(blogPostPage.msgComments.size()-1).getText(),"A moment on your lips forever on your hips.");
        assertEquals(blogPostPage.awaitingComments.getText(),"Your comment is awaiting moderation.");
    }

}
