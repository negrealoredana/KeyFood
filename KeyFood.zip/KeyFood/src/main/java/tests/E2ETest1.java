package tests;

import org.openqa.selenium.Keys;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pages.*;
import utils.TestNgListener;

import static org.testng.Assert.*;

@Listeners(TestNgListener.class)
public class E2ETest1 extends BaseTest {
    HomePage homePage;
    LoginPage loginPage;
    ProductsPage productsPage;
    CartPage cartPage;
    CheckOutPage checkOutPage;

    @Test
    public void checkOrderPlacementLogin() {
        homePage = new HomePage(driver);
        homePage.click(homePage.myAccount);
        loginPage = new LoginPage(driver);
        loginPage.loginInApp();
        loginPage.waitForElementToBeClickable(loginPage.logoutBtn);
        homePage.sendKeys(homePage.searchBar,"ground");
        homePage.searchBar.sendKeys(Keys.ENTER);
        productsPage =new ProductsPage(driver);
        productsPage.click(productsPage.addToCartBtn);
        assertTrue(productsPage.addToCartMsg.getText().contains("has been added to your cart"));
        productsPage.click(productsPage.viewCart);
        cartPage = new CartPage(driver);
        cartPage.click(cartPage.increseQtyBtn);
        cartPage.waitForElementToHaveValue(homePage.noOfItemsInCart,"2" );
        assertEquals(cartPage.price.get(6).getText(),"$11.98");
        cartPage.click(cartPage.proceedToCheckOutBtn);
        checkOutPage = new CheckOutPage(driver);
        checkOutPage.click(checkOutPage.agreeConditions);
        checkOutPage.click(checkOutPage.placeOrderBtn);
        assertEquals(checkOutPage.confirmationText.getText(),"Thank you. Your order has been received.");
        assertNotNull(checkOutPage.orderId);
    }
}
